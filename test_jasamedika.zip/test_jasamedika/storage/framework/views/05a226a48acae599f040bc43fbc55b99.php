

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 12px;">
    <h2>Organizer List</h2>    
    <form action="<?php echo e(route('organizer.detail')); ?>" method="get">
        <input type="submit" value="Add" class="btn_submit" style='width: 100px;'>
    </form>
    
    <div>
        <?php if(count($data)>0): ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="display: inline-block; width: 100px; height: 120px; padding: 4px;">
                <div style="width: 100px; height: 100px; background-color: silver;">
                    <img src="<?php echo e($dt['imageLocation']); ?>" alt="Image not found" width="100px" height="100px"> 
                </div>
                <div style="text-align: center; white-space: nowrap;">
                    <?php echo e($dt['organizerName']); ?>

                </div>
                <div style="text-align: center;">
                    
                        <input type="submit" value="Edit" class="btn_primary" style='width: 40px; padding:0; margin:0;'>
                        <input type="submit" value="Delete" class="btn_error" style='width: 40px; padding:0; margin:0;'>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_voxteneo\resources\views/organizer/list.blade.php ENDPATH**/ ?>