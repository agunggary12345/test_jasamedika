

<?php $__env->startSection('free_style'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="text-align: center;">
    <h1><b>LOGIN</b></h1>
    <form action="<?php echo e(route('user.verify')); ?>" enctype="multipart/form-data" method="post">
        <?php echo e(csrf_field()); ?>

        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" /></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" /></td>
            </tr>        
        </table> 
        <input type="submit" value="Login" class="btn_submit">
    </form>
    <form action="<?php echo e(route('user.register')); ?>" method="get">
        <input type="submit" value="Register" class="btn_primary">
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_jasamedika\resources\views/user/login.blade.php ENDPATH**/ ?>