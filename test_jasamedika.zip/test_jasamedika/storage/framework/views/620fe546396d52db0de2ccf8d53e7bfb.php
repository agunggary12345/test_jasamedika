

<?php $__env->startSection('free_style'); ?>
<style>

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="text-align: center;">
    <h1><b><?php echo e($title); ?></b></h1>
    <form action="<?php echo e(route('user.create')); ?>" enctype="multipart/form-data" method="post">
        <?php echo e(csrf_field()); ?>

        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">First Name</td>
                <td width="80%" style="text-align: left;"><input type="text" name="first_name"/></td>
            </tr>
            <tr>
                <td>Last Name</td>
                <td><input type="text" name="last_name" /></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" /></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" /></td>
            </tr>
            <tr>
                <td>Repeat Password</td>
                <td><input type="password" name="rep_password" /></td>                
            </tr>
        </table> 
        <input type="submit" value="Submit" class="btn_submit">
    </form>
    <form action="<?php echo e(route('user.login')); ?>" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_voxteneo\resources\views/user/register.blade.php ENDPATH**/ ?>