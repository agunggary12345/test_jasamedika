

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 14px;">
    <h2>Car Detail</h2>
    <hr>
    <?php if(isset($data)): ?> 
        <form action="<?php echo e(route('car.update', $data['id'])); ?>" method="post"> 
    <?php else: ?>
        <form action="<?php echo e(route('car.create')); ?>" method="post"> 
    <?php endif; ?>     
        <?php echo e(csrf_field()); ?>

        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Car No/Plat</td>
                <td width="80%" style="text-align: left;"><input type="text" name="car_no" <?php if(isset($data)): ?> value="<?php echo e($data['car_no']); ?>" <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Brand</td>
                <td><input type="text" name="brand" <?php if(isset($data)): ?> value="<?php echo e($data['brand']); ?>" <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Model</td>
                <td><input type="text" name="model" <?php if(isset($data)): ?> value="<?php echo e($data['model']); ?>" <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Unit Price</td>
                <td><input type="number" name="unit_price" <?php if(isset($data)): ?> value="<?php echo e($data['unit_price']); ?>" <?php endif; ?> /></td>
            </tr>            
        </table>        
        <input type="submit" value="Submit" class="btn_submit">
    </form>
    <form action="<?php echo e(route('car.list')); ?>" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_jasamedika\resources\views/car/detail.blade.php ENDPATH**/ ?>