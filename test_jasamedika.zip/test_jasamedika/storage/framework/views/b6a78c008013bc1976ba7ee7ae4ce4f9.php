<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo e(config('app.name')); ?></title>
        
        <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" >
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        <style>
            body {
                font-family: Arial, Helvetica, sans-serif;
            }   
            
            input[type=text], input[type=email], input[type=password], select {
                width: 100%;
                padding: 8px 8px;
                margin: 4px 0;
                display: inline-block;
                border: 1px solid #ccc;
                border-radius: 4px;
                box-sizing: border-box;
            }

            input[type=submit], input[type=button] {
                width: 100%;                
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }            
            
            .btn_submit {
                background-color: #4CAF50;
            }

            .btn_submit:hover {
                background-color: #45a049;
            }

            .btn_primary {
                background-color: #1671fa;
            }

            .btn_primary:hover {
                background-color: #104ba3;
            }

            .btn_error {
                background-color: #f7193a;
            }

            .btn_error:hover {
                background-color: #b8162e;
            }

            div {
                border-radius: 5px;
                background-color: #f2f2f2;
                /* padding: 20px; */
            }
        </style>

        <?php echo $__env->yieldContent('free_style'); ?>
    </head>
    <body class="antialiased">
        <div class="container">
        <?php echo $__env->make('inc.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        </div>        
            
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\test_voxteneo\resources\views/layouts/app.blade.php ENDPATH**/ ?>