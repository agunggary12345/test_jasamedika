

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 14px;">
    <h2>Rent Car Detail</h2>
    <hr>    
    <form action="<?php echo e(route('rent.create')); ?>" method="post">     
        <?php echo e(csrf_field()); ?>

        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Trans No</td>
                <td width="80%" style="text-align: left;"><input type="text" name="trans_no" <?php if(isset($data)): ?> value="<?php echo e($data['trans_no']); ?>" <?php endif; ?> <?php if(isset($next_no)): ?> value="<?php echo e($next_no); ?>" <?php endif; ?> readonly /></td>
            </tr>
            <tr>
                <td>Start Date</td>
                <td><input type="date" name="start_date" <?php if(isset($data)): ?> value="<?php echo e($data['start_date']); ?>" readonly <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Finish Date</td>
                <td><input type="date" name="finish_date" <?php if(isset($data)): ?> value="<?php echo e($data['finish_date']); ?>" readonly <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Select a Car</td>
                <td>
                    <?php if(isset($cars)): ?>
                    <select name="car">                        
                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($car['id']); ?>"><?php echo e($car['car_no']); ?> (<?php echo e($car['brand']); ?> - <?php echo e($car['model']); ?>): <?php echo e($car['unit_price']); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </select>
                    <?php endif; ?>

                    <?php if(isset($data)): ?>
                    <input type="text" <?php if(isset($data)): ?> value="<?php echo e($data['car']['car_no']); ?> (<?php echo e($data['car']['brand']); ?> - <?php echo e($data['car']['model']); ?>): <?php echo e($data['car']['unit_price']); ?>" <?php endif; ?> readonly />
                    <?php endif; ?>
                </td>
            </tr>            
        </table> 
        <?php if(!isset($data)): ?> 
            <input type="submit" value="Submit" class="btn_submit">
        <?php endif; ?>
    </form>
    <form action="<?php echo e(route('rent.list')); ?>" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_jasamedika\resources\views/rent/detail.blade.php ENDPATH**/ ?>