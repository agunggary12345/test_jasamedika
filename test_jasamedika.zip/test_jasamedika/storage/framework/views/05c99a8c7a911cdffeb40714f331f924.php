

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 12px;">
    <h2>Organizer Detail</h2>    
    
    <div>
        <div>
            <b>Image : <input type="file" id="idImg" name="filename"></b>
            <div style='background-color: silver; width: 300px; height: 300px;'>
                
                <img src="" alt="Image not available" width="100px" height="100px"> 
            </div>
        </div>
        
        <div style="text-align: center; white-space: nowrap;">
            <b>Organizer Name :</b> <input type="text" name="organizer_name"/>
        </div>
        <div style="text-align: center;">
            
            <input type="submit" value="Save" class="btn_submit" style='width: 30%; '>
            <input type="button" value="Close" class="btn_error" style='width: 30%; ' onclick="history.back()">
            
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_voxteneo\resources\views/organizer/detail.blade.php ENDPATH**/ ?>