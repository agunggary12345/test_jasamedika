

<?php $__env->startSection('free_style'); ?>
<style>
    .navbar {
        overflow: hidden;
        background-color: #333;
    }

    .navbar a {
        float: left;
        font-size: 16px;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }    

    .navbar a:hover {
        background-color: red;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="text-align: left; margin-top: -16px;">
    <h1><b>Home</b></h1>
    <div class="navbar" style="margin-top: -16px;">
        <a href="<?php echo e(route('organizer.list')); ?>">Organizer</a>
        <a href="#news">Sport Event</a>
        <a href="#news">User</a>
        <a href="#news">Logout</a>
    </div>
    
    <?php echo $__env->yieldContent('content2'); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_voxteneo\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>