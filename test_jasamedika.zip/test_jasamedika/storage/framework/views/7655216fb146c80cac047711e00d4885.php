

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 14px;">
    <h2>User Profile</h2>
    <hr>
    <?php if(isset($data)): ?> 
        <form action="<?php echo e(route('user.update', $data['id'])); ?>" method="post">     
    <?php endif; ?>     
        <?php echo e(csrf_field()); ?>

        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Email</td>
                <td width="80%" style="text-align: left;"><input type="text" <?php if(isset($data)): ?> value="<?php echo e($data['email']); ?>" <?php endif; ?> readonly/></td>
            </tr>
            <tr>
                <td width="20%">Register Time</td>
                <td width="80%" style="text-align: left;"><input type="text" <?php if(isset($data)): ?> value="<?php echo e($data['created_at']); ?>" <?php endif; ?> readonly/></td>
            </tr>
            <tr>
                <td width="20%">Name</td>
                <td width="80%" style="text-align: left;"><input type="text" name="name" <?php if(isset($data)): ?> value="<?php echo e($data['name']); ?>" <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><input type="text" name="address" <?php if(isset($data)): ?> value="<?php echo e($data['address']); ?>" <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Phone</td>
                <td><input type="text" name="phone" <?php if(isset($data)): ?> value="<?php echo e($data['phone']); ?>" <?php endif; ?> /></td>
            </tr>
            <tr>
                <td>Driver License</td>
                <td><input type="text" name="driver_license" <?php if(isset($data)): ?> value="<?php echo e($data['driver_license']); ?>" <?php endif; ?> /></td>
            </tr>            
        </table>        
        <input type="submit" value="Submit" class="btn_submit">
    </form>
    <form action="<?php echo e(route('dashboard.index')); ?>" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_jasamedika\resources\views/user/profile.blade.php ENDPATH**/ ?>