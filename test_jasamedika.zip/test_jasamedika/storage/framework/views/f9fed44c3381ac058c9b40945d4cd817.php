

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 14px;">
    <h2>Rent Car List</h2>
    <hr>
    <form action="<?php echo e(route('rent.list')); ?>" method="get">
        <label style="margin-left: 5%; font-size: 9px;"><i>You can search by Trans No </i></label><br>
        <label><b>Search: </b></label>
        <input type="text" name="search" style="width: 80%" <?php if(isset($search)): ?> value="<?php echo e($search); ?>" <?php endif; ?> />
        <input type="submit" value="Search" class="btn_primary" style='width: 60px; padding:8px;'>
    </form>

    <form action="<?php echo e(route('rent.detail', 0)); ?>" method="get">
        <input type="submit" value="Add" class="btn_submit" style='width: 60px; padding:8px;'>
    </form>
    <div>
        <table class="table-list">
		    <tr>
			    <th width="5%" style="text-align:right;">No</th>
			    <th width="15%">Trans No</th>
			    <th width="10%">Start Date</th>
			    <th width="10%">Finish Date</th>
			    <th width="20%">User</th>
			    <th width="12%">Car No</th>
			    <th width="20%">Model</th>
			    <th width="8%" style="text-align:center;">Action</th>			    
		    </tr>
		    <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
                <td style="text-align:right;"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($rent->trans_no); ?></td>
                <td><?php echo e($rent->start_date); ?></td>
                <td><?php echo e($rent->finish_date); ?></td>
                <td><?php echo e($rent->user->name); ?></td>
                <td><?php echo e($rent->car->car_no); ?></td>
                <td><?php echo e($rent->car->model); ?></td>
                <td style="text-align:center;">
                    <form action="<?php echo e(route('rent.detail', $rent->id)); ?>" method="get" style="display: inline;">
                        <input type="submit" value="Detail" class="btn_primary" style='width: 45%; padding:2px;'>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($rents) === 0): ?>
            <tr>
                <td colspan="9" style="text-align:center;">There is No data!</td>
            </tr>
            <?php endif; ?>
	    </table>
 
	    <br/>
        Page : <?php echo e($rents->currentPage()); ?> <br/>
        Total Data : <?php echo e($rents->total()); ?> <br/>
        Data Per Page : <?php echo e($rents->perPage()); ?> <br/>
 
	    <?php echo e($rents->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_jasamedika\resources\views/rent/list.blade.php ENDPATH**/ ?>