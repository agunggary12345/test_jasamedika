

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 14px;">
    <h2>Rent Return List</h2>
    <hr>
    <form action="<?php echo e(route('rent_return.list')); ?>" method="get">
        <label style="margin-left: 5%; font-size: 9px;"><i>You can search by Trans No </i></label><br>
        <label><b>Search: </b></label>
        <input type="text" name="search" style="width: 80%" <?php if(isset($search)): ?> value="<?php echo e($search); ?>" <?php endif; ?> />
        <input type="submit" value="Search" class="btn_primary" style='width: 60px; padding:8px;'>
    </form>

    <form action="<?php echo e(route('rent_return.detail', 0)); ?>" method="get">
        <input type="submit" value="Add" class="btn_submit" style='width: 60px; padding:8px;'>
    </form>
    <div>
        <table class="table-list">
		    <tr>
			    <th width="5%" style="text-align:right;">No</th>
			    <th width="15%">Trans No</th>
			    <th width="10%">Trans Date</th>			    
			    <th width="20%">User</th>
			    <th width="10%">Car No</th>
			    <th width="12%" style="text-align:right;">Unit Price</th>
                <th width="5%" style="text-align:right;">Days</th>
                <th width="15%" style="text-align:right;">Amount</th>
			    <th width="8%" style="text-align:center;">Action</th>			    
		    </tr>
		    <?php $__currentLoopData = $rent_returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rent_return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
                <td style="text-align:right;"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($rent_return->trans_no); ?></td>
                <td><?php echo e($rent_return->trans_date); ?></td>                
                <td><?php echo e($rent_return->user->name); ?></td>
                <td><?php echo e($rent_return->rent->car->car_no); ?></td>
                <td style="text-align:right;"><?php echo e($rent_return->rent->car->unit_price); ?></td>
                <td style="text-align:right;"><?php echo e($rent_return->days); ?></td>
                <td style="text-align:right;"><?php echo e($rent_return->amount); ?></td>
                <td style="text-align:center;">
                    <form action="<?php echo e(route('rent_return.detail', $rent_return->id)); ?>" method="get" style="display: inline;">
                        <input type="submit" value="Detail" class="btn_primary" style='width: 45%; padding:2px;'>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($rent_returns) === 0): ?>
            <tr>
                <td colspan="9" style="text-align:center;">There is No data!</td>
            </tr>
            <?php endif; ?>
	    </table>
 
	    <br/>
        Page : <?php echo e($rent_returns->currentPage()); ?> <br/>
        Total Data : <?php echo e($rent_returns->total()); ?> <br/>
        Data Per Page : <?php echo e($rent_returns->perPage()); ?> <br/>
 
	    <?php echo e($rent_returns->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_jasamedika\resources\views/rent_return/list.blade.php ENDPATH**/ ?>