

<?php $__env->startSection('content2'); ?>
<div style="text-align: left; font-size: 14px;">
    <h2>Car List</h2>
    <hr>
    <form action="<?php echo e(route('car.list')); ?>" method="get">
        <label style="margin-left: 5%; font-size: 9px;"><i>You can search by Car No or Brand or Model </i></label><br>
        <label><b>Search: </b></label>
        <input type="text" name="search" style="width: 80%" <?php if(isset($search)): ?> value="<?php echo e($search); ?>" <?php endif; ?> />
        <input type="submit" value="Search" class="btn_primary" style='width: 60px; padding:8px;'>
    </form>

    <form action="<?php echo e(route('car.detail', 0)); ?>" method="get">
        <input type="submit" value="Add" class="btn_submit" style='width: 60px; padding:8px;'>
    </form>    
    <div>
        <table class="table-list">
		    <tr>
			    <th width="5%" style="text-align:right;">No</th>
			    <th width="15%">Car No</th>
			    <th width="30%">Brand</th>
			    <th width="30%">Model</th>
			    <th width="12%" style="text-align:right;">Unit Price</th>
			    <th width="8%" style="text-align:center;">Action</th>
		    </tr>
		    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    <tr>
                <td style="text-align:right;"><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($car->car_no); ?></td>
                <td><?php echo e($car->brand); ?></td>
                <td><?php echo e($car->model); ?></td>                
                <td style="text-align:right;"><?php echo e($car->unit_price); ?></td>
                <td style="text-align:center;">
                    <form action="<?php echo e(route('car.detail', $car->id)); ?>" method="get" style="display: inline;">
                        <input type="submit" value="Edit" class="btn_primary" style='width: 45%; padding:2px;'>
                    </form>
                    <form action="<?php echo e(route('car.delete', $car->id)); ?>" method="delete" style="display: inline;">
                        <input type="submit" value="Delete" class="btn_error" style='width: 45%; padding:2px;' onclick="return confirm('Are you sure delete this data?')">
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(count($cars) === 0): ?>
            <tr>
                <td colspan="6" style="text-align:center;">There is No data!</td>                
            </tr>
            <?php endif; ?>
	    </table>
 
	    <br/>
        Page : <?php echo e($cars->currentPage()); ?> <br/>
        Total Data : <?php echo e($cars->total()); ?> <br/>
        Data Per Page : <?php echo e($cars->perPage()); ?> <br/>
 
 
	    <?php echo e($cars->links()); ?>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test_jasamedika\resources\views/car/list.blade.php ENDPATH**/ ?>