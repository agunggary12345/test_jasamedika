@extends('layouts.dashboard')

@section('content2')
<div style="text-align: left; font-size: 14px;">
    <h2>Car List</h2>
    <hr>
    <form action="{{ route('car.list') }}" method="get">
        <label style="margin-left: 5%; font-size: 9px;"><i>You can search by Car No or Brand or Model </i></label><br>
        <label><b>Search: </b></label>
        <input type="text" name="search" style="width: 80%" @if(isset($search)) value="{{ $search }}" @endif />
        <input type="submit" value="Search" class="btn_primary" style='width: 60px; padding:8px;'>
    </form>

    <form action="{{ route('car.detail', 0) }}" method="get">
        <input type="submit" value="Add" class="btn_submit" style='width: 60px; padding:8px;'>
    </form>    
    <div>
        <table class="table-list">
		    <tr>
			    <th width="5%" style="text-align:right;">No</th>
			    <th width="15%">Car No</th>
			    <th width="30%">Brand</th>
			    <th width="30%">Model</th>
			    <th width="12%" style="text-align:right;">Unit Price</th>
			    <th width="8%" style="text-align:center;">Action</th>
		    </tr>
		    @foreach($cars as $car)
		    <tr>
                <td style="text-align:right;">{{ $loop->iteration }}</td>
                <td>{{ $car->car_no }}</td>
                <td>{{ $car->brand }}</td>
                <td>{{ $car->model }}</td>                
                <td style="text-align:right;">{{ $car->unit_price }}</td>
                <td style="text-align:center;">
                    <form action="{{ route('car.detail', $car->id) }}" method="get" style="display: inline;">
                        <input type="submit" value="Edit" class="btn_primary" style='width: 45%; padding:2px;'>
                    </form>
                    <form action="{{ route('car.delete', $car->id) }}" method="delete" style="display: inline;">
                        <input type="submit" value="Delete" class="btn_error" style='width: 45%; padding:2px;' onclick="return confirm('Are you sure delete this data?')">
                    </form>
                </td>
            </tr>
            @endforeach

            @if(count($cars) === 0)
            <tr>
                <td colspan="6" style="text-align:center;">There is No data!</td>                
            </tr>
            @endif
	    </table>
 
	    <br/>
        Page : {{ $cars->currentPage() }} <br/>
        Total Data : {{ $cars->total() }} <br/>
        Data Per Page : {{ $cars->perPage() }} <br/>
 
 
	    {{ $cars->links() }}
    </div>

</div>
@endsection
