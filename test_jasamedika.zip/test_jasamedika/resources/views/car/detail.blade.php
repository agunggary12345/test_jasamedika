@extends('layouts.dashboard')

@section('content2')
<div style="text-align: left; font-size: 14px;">
    <h2>Car Detail</h2>
    <hr>
    @if(isset($data)) 
        <form action="{{ route('car.update', $data['id']) }}" method="post"> 
    @else
        <form action="{{ route('car.create') }}" method="post"> 
    @endif     
        {{ csrf_field() }}
        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Car No/Plat</td>
                <td width="80%" style="text-align: left;"><input type="text" name="car_no" @if(isset($data)) value="{{ $data['car_no'] }}" @endif /></td>
            </tr>
            <tr>
                <td>Brand</td>
                <td><input type="text" name="brand" @if(isset($data)) value="{{ $data['brand'] }}" @endif /></td>
            </tr>
            <tr>
                <td>Model</td>
                <td><input type="text" name="model" @if(isset($data)) value="{{ $data['model'] }}" @endif /></td>
            </tr>
            <tr>
                <td>Unit Price</td>
                <td><input type="number" name="unit_price" @if(isset($data)) value="{{ $data['unit_price'] }}" @endif /></td>
            </tr>            
        </table>        
        <input type="submit" value="Submit" class="btn_submit">
    </form>
    <form action="{{ route('car.list') }}" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>

</div>
@endsection
