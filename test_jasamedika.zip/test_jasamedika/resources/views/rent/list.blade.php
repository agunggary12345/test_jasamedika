@extends('layouts.dashboard')

@section('content2')
<div style="text-align: left; font-size: 14px;">
    <h2>Rent Car List</h2>
    <hr>
    <form action="{{ route('rent.list') }}" method="get">
        <label style="margin-left: 5%; font-size: 9px;"><i>You can search by Trans No </i></label><br>
        <label><b>Search: </b></label>
        <input type="text" name="search" style="width: 80%" @if(isset($search)) value="{{ $search }}" @endif />
        <input type="submit" value="Search" class="btn_primary" style='width: 60px; padding:8px;'>
    </form>

    <form action="{{ route('rent.detail', 0) }}" method="get">
        <input type="submit" value="Add" class="btn_submit" style='width: 60px; padding:8px;'>
    </form>
    <div>
        <table class="table-list">
		    <tr>
			    <th width="5%" style="text-align:right;">No</th>
			    <th width="15%">Trans No</th>
			    <th width="10%">Start Date</th>
			    <th width="10%">Finish Date</th>
			    <th width="20%">User</th>
			    <th width="12%">Car No</th>
			    <th width="20%">Model</th>
			    <th width="8%" style="text-align:center;">Action</th>			    
		    </tr>
		    @foreach($rents as $rent)
		    <tr>
                <td style="text-align:right;">{{ $loop->iteration }}</td>
                <td>{{ $rent->trans_no }}</td>
                <td>{{ $rent->start_date }}</td>
                <td>{{ $rent->finish_date }}</td>
                <td>{{ $rent->user->name }}</td>
                <td>{{ $rent->car->car_no }}</td>
                <td>{{ $rent->car->model }}</td>
                <td style="text-align:center;">
                    <form action="{{ route('rent.detail', $rent->id) }}" method="get" style="display: inline;">
                        <input type="submit" value="Detail" class="btn_primary" style='width: 45%; padding:2px;'>
                    </form>
                </td>
            </tr>
            @endforeach

            @if(count($rents) === 0)
            <tr>
                <td colspan="9" style="text-align:center;">There is No data!</td>
            </tr>
            @endif
	    </table>
 
	    <br/>
        Page : {{ $rents->currentPage() }} <br/>
        Total Data : {{ $rents->total() }} <br/>
        Data Per Page : {{ $rents->perPage() }} <br/>
 
	    {{ $rents->links() }}
    </div>

</div>
@endsection
