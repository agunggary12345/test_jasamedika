@extends('layouts.dashboard')

@section('content2')
<div style="text-align: left; font-size: 14px;">
    <h2>Rent Car Detail</h2>
    <hr>    
    <form action="{{ route('rent.create') }}" method="post">     
        {{ csrf_field() }}
        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Trans No</td>
                <td width="80%" style="text-align: left;"><input type="text" name="trans_no" @if(isset($data)) value="{{ $data['trans_no'] }}" @endif @if(isset($next_no)) value="{{ $next_no }}" @endif readonly /></td>
            </tr>
            <tr>
                <td>Start Date</td>
                <td><input type="date" name="start_date" @if(isset($data)) value="{{ $data['start_date'] }}" readonly @endif /></td>
            </tr>
            <tr>
                <td>Finish Date</td>
                <td><input type="date" name="finish_date" @if(isset($data)) value="{{ $data['finish_date'] }}" readonly @endif /></td>
            </tr>
            <tr>
                <td>Select a Car</td>
                <td>
                    @if(isset($cars))
                    <select name="car">                        
                        @foreach($cars as $car)
                        <option value="{{ $car['id'] }}">{{ $car['car_no'] }} ({{ $car['brand'] }} - {{ $car['model'] }}): {{ $car['unit_price'] }} </option>
                        @endforeach                        
                    </select>
                    @endif

                    @if(isset($data))
                    <input type="text" @if(isset($data)) value="{{ $data['car']['car_no'] }} ({{ $data['car']['brand'] }} - {{ $data['car']['model'] }}): {{ $data['car']['unit_price'] }}" @endif readonly />
                    @endif
                </td>
            </tr>            
        </table> 
        @if(!isset($data)) 
            <input type="submit" value="Submit" class="btn_submit">
        @endif
    </form>
    <form action="{{ route('rent.list') }}" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>

</div>
@endsection
