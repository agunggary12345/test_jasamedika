@extends('layouts.dashboard')

@section('content2')
<div style="text-align: left; font-size: 14px;">
    <h2>Rent Return List</h2>
    <hr>
    <form action="{{ route('rent_return.list') }}" method="get">
        <label style="margin-left: 5%; font-size: 9px;"><i>You can search by Trans No </i></label><br>
        <label><b>Search: </b></label>
        <input type="text" name="search" style="width: 80%" @if(isset($search)) value="{{ $search }}" @endif />
        <input type="submit" value="Search" class="btn_primary" style='width: 60px; padding:8px;'>
    </form>

    <form action="{{ route('rent_return.detail', 0) }}" method="get">
        <input type="submit" value="Add" class="btn_submit" style='width: 60px; padding:8px;'>
    </form>
    <div>
        <table class="table-list">
		    <tr>
			    <th width="5%" style="text-align:right;">No</th>
			    <th width="15%">Trans No</th>
			    <th width="10%">Trans Date</th>			    
			    <th width="20%">User</th>
			    <th width="10%">Car No</th>
			    <th width="12%" style="text-align:right;">Unit Price</th>
                <th width="5%" style="text-align:right;">Days</th>
                <th width="15%" style="text-align:right;">Amount</th>
			    <th width="8%" style="text-align:center;">Action</th>			    
		    </tr>
		    @foreach($rent_returns as $rent_return)
		    <tr>
                <td style="text-align:right;">{{ $loop->iteration }}</td>
                <td>{{ $rent_return->trans_no }}</td>
                <td>{{ $rent_return->trans_date }}</td>                
                <td>{{ $rent_return->user->name }}</td>
                <td>{{ $rent_return->rent->car->car_no }}</td>
                <td style="text-align:right;">{{ $rent_return->rent->car->unit_price }}</td>
                <td style="text-align:right;">{{ $rent_return->days }}</td>
                <td style="text-align:right;">{{ $rent_return->amount }}</td>
                <td style="text-align:center;">
                    <form action="{{ route('rent_return.detail', $rent_return->id) }}" method="get" style="display: inline;">
                        <input type="submit" value="Detail" class="btn_primary" style='width: 45%; padding:2px;'>
                    </form>
                </td>
            </tr>
            @endforeach

            @if(count($rent_returns) === 0)
            <tr>
                <td colspan="9" style="text-align:center;">There is No data!</td>
            </tr>
            @endif
	    </table>
 
	    <br/>
        Page : {{ $rent_returns->currentPage() }} <br/>
        Total Data : {{ $rent_returns->total() }} <br/>
        Data Per Page : {{ $rent_returns->perPage() }} <br/>
 
	    {{ $rent_returns->links() }}
    </div>

</div>
@endsection
