@extends('layouts.dashboard')

@section('content2')
<div style="text-align: left; font-size: 14px;">
    <h2>Rent Car Detail</h2>
    <hr>    
    <form action="{{ route('rent_return.create') }}" method="post">     
        {{ csrf_field() }}
        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Trans No</td>
                <td width="80%" style="text-align: left;"><input type="text" name="trans_no" @if(isset($data)) value="{{ $data['trans_no'] }}" @endif @if(isset($next_no)) value="{{ $next_no }}" @endif readonly /></td>
            </tr>
            <tr>
                <td>Trans Date</td>
                <td><input type="date" name="trans_date" @if(isset($data)) value="{{ $data['trans_date'] }}" readonly @endif /></td>
            </tr>            
            <tr>
                <td>Rent Trans No</td>
                <td>
                    @if(isset($rents))
                    <select name="rent">                        
                        @foreach($rents as $rent)
                        <option value="{{ $rent['id'] }}">{{ $rent['trans_no'] }} (Car No: {{ $rent['car']['brand'] }}) </option>
                        @endforeach                        
                    </select>
                    @endif
                </td>
            </tr>            
        </table> 
        @if(!isset($data)) 
            <input type="submit" value="Submit" class="btn_submit">
        @endif
    </form>
    <form action="{{ route('rent_return.list') }}" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>

</div>
@endsection
