@extends('layouts.app')

@section('free_style')
<style>

</style>
@endsection

@section('content')
<div style="text-align: center;">
    <h1><b>{{$title}}</b></h1>
    <form action="{{ route('user.create') }}" enctype="multipart/form-data" method="post">
        {{ csrf_field() }}
        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Name</td>
                <td width="80%" style="text-align: left;"><input type="text" name="name"/></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" /></td>
            </tr>
            <tr>
                <td>Phone</td>
                <td><input type="text" name="phone" /></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><input type="text" name="address" /></td>
            </tr>
            <tr>
                <td>Driver License</td>
                <td><input type="text" name="driver_license" /></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" /></td>
            </tr>
            <tr>
                <td>Repeat Password</td>
                <td><input type="password" name="rep_password" /></td>                
            </tr>
        </table> 
        <input type="submit" value="Submit" class="btn_submit">
    </form>
    <form action="{{ route('user.login') }}" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>
</div>
@endsection
