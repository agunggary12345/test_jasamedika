@extends('layouts.app')

@section('free_style')
<style>

</style>
@endsection

@section('content')
<div style="text-align: center;">
    <h1><b>LOGIN</b></h1>
    <form action="{{ route('user.verify') }}" enctype="multipart/form-data" method="post">
        {{ csrf_field() }}
        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" /></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password" /></td>
            </tr>        
        </table> 
        <input type="submit" value="Login" class="btn_submit">
    </form>
    <form action="{{ route('user.register') }}" method="get">
        <input type="submit" value="Register" class="btn_primary">
    </form>

</div>
@endsection
