@extends('layouts.dashboard')

@section('content2')
<div style="text-align: left; font-size: 14px;">
    <h2>User Profile</h2>
    <hr>
    @if(isset($data)) 
        <form action="{{ route('user.update', $data['id']) }}" method="post">     
    @endif     
        {{ csrf_field() }}
        <table class="table1" style="text-align: left;" width="100%">
            <tr>
                <td width="20%">Email</td>
                <td width="80%" style="text-align: left;"><input type="text" @if(isset($data)) value="{{ $data['email'] }}" @endif readonly/></td>
            </tr>
            <tr>
                <td width="20%">Register Time</td>
                <td width="80%" style="text-align: left;"><input type="text" @if(isset($data)) value="{{ $data['created_at'] }}" @endif readonly/></td>
            </tr>
            <tr>
                <td width="20%">Name</td>
                <td width="80%" style="text-align: left;"><input type="text" name="name" @if(isset($data)) value="{{ $data['name'] }}" @endif /></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><input type="text" name="address" @if(isset($data)) value="{{ $data['address'] }}" @endif /></td>
            </tr>
            <tr>
                <td>Phone</td>
                <td><input type="text" name="phone" @if(isset($data)) value="{{ $data['phone'] }}" @endif /></td>
            </tr>
            <tr>
                <td>Driver License</td>
                <td><input type="text" name="driver_license" @if(isset($data)) value="{{ $data['driver_license'] }}" @endif /></td>
            </tr>            
        </table>        
        <input type="submit" value="Submit" class="btn_submit">
    </form>
    <form action="{{ route('dashboard.index') }}" method="get">
        <input type="submit" value="Back" class="btn_error">
    </form>

</div>
@endsection
