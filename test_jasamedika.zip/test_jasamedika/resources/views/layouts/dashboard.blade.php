@extends('layouts.app')

@section('free_style')
<style>
    .navbar {
        overflow: hidden;
        background-color: #333;
    }

    .navbar a {
        float: left;
        font-size: 16px;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }    

    .navbar a:hover {
        background-color: red;
    }

    table.table-list{
        border: 1px solid #333;
        width: 100%;
        border-collapse: collapse;        
    }

    th{
        padding: 8px;
    }

    td{
        padding: 4px;
    }

    table.table-list th{
        border: 1px solid #333;
        background-color: #333;
        color: white;
    }

    table.table-list td{
        border: 1px solid #333;
    }

    table.table-list tr:nth-child(odd){
        background-color: #eee;
    }

    table.table-list tr:nth-child(odd){
        background-color: white;
    }

</style>
@endsection

@section('content')
<div style="text-align: left; margin-top: -16px;">
    <h1><b>Car Rental</b></h1>
    <div class="navbar" style="margin-top: -16px;">
        <a href="{{ route('car.list') }}">Car</a>
        <a href="{{ route('rent.list') }}">Rent Car</a>
        <a href="{{ route('rent_return.list') }}">Rent Return</a>
        <a href="{{ route('user.profile') }}">Profil</a>
        <a href="{{ route('user.logout') }}">Logout</a>
    </div>
    
    @yield('content2')
</div>
@endsection
