<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RentReturn extends Model
{
    use HasFactory;

    protected $fillable = [
        'trans_no',
        'trans_date',
        'days',
        'unit_price',        
        'amount',
        'rent_id',
        'user_id'
    ];

    public function rent()
    {
        return $this->belongsTo(Rent::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
