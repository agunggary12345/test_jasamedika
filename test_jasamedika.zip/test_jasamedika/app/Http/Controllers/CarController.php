<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Car;

class CarController extends Controller
{
    public function index(Request $request){
        if($request->session()->has('user_email')){
            $token = $request->session()->get('user_email');
		}else{
            return redirect('/');
		}

        $page = 1;
        $per_page = 30;

        if (isset($request['search'])){
            $search = $request['search'];
            $cars = Car::whereRaw("UPPER(car_no) LIKE '%".strtoupper($search)."%' or UPPER(brand) LIKE '%".strtoupper($search)."%' or UPPER(model) LIKE '%".strtoupper($search)."%'")->paginate(
                $perPage = 30, $columns = ['*'], $pageName = 'cars'
            );

            return view('car.list', ['cars' => $cars, 'search' => $search]);
        }
        else{
            $cars = Car::paginate(
                $perPage = 30, $columns = ['*'], $pageName = 'cars'
            );
        }

        return view('car.list', ['cars' => $cars]);
    }  
    
    public function detail($id){ 
        // if (isset($request['id'])){
        if (isset($id)){
            if ($id > 0){
                $car = Car::find($id);
                $data = array(
                    'id' => $id,
                    'car_no' => $car['car_no'],
                    'brand' => $car['brand'],
                    'model' => $car['model'],
                    'unit_price' => $car['unit_price'],
                );                
                error_log($car['car_no']);
                return view('car.detail')->with('data', $data);
            }            
        }       
        return view('car.detail');
    }

    public function create(Request $request){
        $this->validate($request, [
            'car_no' => 'required',
            'brand' => 'required',
            'model' => 'required',
            'unit_price' => 'required|numeric',
        ]);

        $car_no = $request['car_no'];
        $brand = $request['brand'];
        $model = $request['model'];
        $unit_price = $request['unit_price'];

        $car = Car::where('car_no', $car_no)->exists();
        if ($car){            
            return redirect('/car/detail')->with('err','Car No already exist!');
        }
        
        $car = Car::create([            
            'car_no' => $car_no,
            'brand' => $brand,
            'model' => $model,
            'unit_price' => $unit_price
        ]);
        
        return redirect('/car/list')->with('success','Add new data success.');
        // return view('car.list', ['cars' => null]);
        
    }

    public function update(Request $request, $id){
        $this->validate($request, [
            'car_no' => 'required',
            'brand' => 'required',
            'model' => 'required',
            'unit_price' => 'required|numeric',
        ]);

        $car_no = $request['car_no'];
        $brand = $request['brand'];
        $model = $request['model'];
        $unit_price = $request['unit_price'];

        $car = Car::find($id);
        if ($car){
            $car->car_no = $car_no;
            $car->brand = $brand;
            $car->model = $model;
            $car->unit_price = $unit_price;
            $car->save();
            return redirect('/car/list')->with('success','Update data success.');
        }
        else{
            return redirect('/car/list')->with('err','Data is not valid!');
        }                        
    }

    public function delete($id){
        if (isset($id)){
            $car = Car::find($id);
            $car->delete();

            return redirect('/car/list')->with('success','Delete data success.');
        }        
                        
        return redirect('/car/list')->with('err','Data is not valid!');                         
    }
}
