<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\RentReturn;
use App\Models\Rent;
use DateTime;

class RentReturnController extends Controller
{
    public function index(Request $request){
        if($request->session()->has('user_email')){
            $token = $request->session()->get('user_email');
		}else{
            return redirect('/');
		}

        $page = 1;
        $per_page = 30;

        $user_id = Auth::user()->id;
        if (isset($request['search'])){
            $search = $request['search'];
            $rent_returns = RentReturn::whereRaw("user_id = '.$user_id.' and UPPER(trans_no) LIKE '%".strtoupper($search)."%'")->paginate(
                $perPage = 30, $columns = ['*'], $pageName = 'rent_returns'
            );

            return view('rent_return.list', ['rent_returns' => $rent_returns, 'search' => $search]);
        }
        else{
            $rent_returns = RentReturn::where('user_id', $user_id)->paginate(
                $perPage = 30, $columns = ['*'], $pageName = 'rent_returns'
            );
        }

        return view('rent_return.list', ['rent_returns' => $rent_returns]);
    }  
    
    public function detail(Request $request, $id){
        if (isset($id)){
            if ($id > 0){
                $rent_return = RentReturn::find($id);
                $data = array(
                    'id' => $id,
                    'trans_no' => $rent_return['trans_no'],
                    'trans_date' => $rent_return['start_date'],                    
                    'user' => $rent_return['user'],
                    'rent' => $rent_return['rent'],
                    'days' => $rent_return['days'],
                    'unit_price' => $rent_return['unit_price'],
                    'amount' => $rent_return['amount'],
                );
                return view('rent_return.detail')->with('data', $data);
            }
        }

        if (!isset($id) || $id == 0){
            $max = RentReturn::whereDate('created_at', '=', date('Y-m-d'))->max('trans_no');
            if ($max){
                $max_str = substr($max, 9); 
                $next = (int) $max_str;
                $next = $next + 1;
            }
            else{
                $next = 1;
            }
            $next_no = str_pad($next, 4, '0', STR_PAD_LEFT);
            $next_no = 'R'. date('Ymd') . $next_no;            
            
            $rents = Rent::where('returned', 0)->get();
        }
        
        return view('rent_return.detail', ['next_no' => $next_no, 'rents' => $rents]);
    }

    public function create(Request $request){
        $this->validate($request, [
            'trans_no' => 'required',
            'trans_date' => 'required',            
            'rent' => 'required',
        ]);

        $user_id = Auth::user()->id;
        $trans_no = $request['trans_no'];
        $trans_date = $request['trans_date'];
        $rent_id = $request['rent'];        

        $rent = Rent::find($rent_id)->first();

        // $start_date = strtotime($rent['start_date']);
        // $finish_date = strtotime($rent['finish_date']);
        // $start_date = new DateTime($rent['start_date']);
        // $finish_date = new DateTime($rent['finish_date']);        

        // $days = date_diff($finish_date, $start_date);
        // $days = ($days / (60 * 60 * 24));
        // $interval = $start_date->diff($finish_date);
        // $interval = $interval;
        // if ($days == 0) {
        //     $days = 1;
        // }

        $start_date = strtotime($rent['start_date']);
        $finish_date = strtotime($rent['finish_date']);
        $diff = $finish_date - $start_date;
        $days = floor($diff / (60 * 60 * 24));

        if ($days == 0) {
            $days = 1;
        }
        
        $amount = $days * $rent['unit_price'];                                   
        
        $rent = RentReturn::create([
            'trans_no' => $trans_no,
            'trans_date' => $trans_date,
            'rent_id' => $rent_id,
            'user_id' => $user_id,
            'days' => $days,
            'unit_price' => $rent['unit_price'],
            'amount' => $amount
        ]);

        $rent = Rent::find($rent_id);
        if ($rent){
            $rent->returned = 1;
            $rent->save();
        }

        return redirect('/rent_return/list')->with('success','Add new data success.');        
        
    }    
}
