<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class UserController extends Controller
{
    public function login(){        
        return view('user.login');
    }

    public function register(){
        // return 'Halaman Index';        
        $data = array(
            'title' => 'Register User Baru',
            'contains' => ['Nama', 'No Telp', 'Alamat', 'No SIM', 'Password', 'Repeat Password']
        );
        return view('user.register')->with($data);
    }

    public function create(Request $request){
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email',
            'phone' => 'required',            
            'address' => 'required',
            'driver_license' => 'required',
            'password' => 'required|same:rep_password|min:8',
            'rep_password' => 'required|same:password|min:8'
        ]);        
        
        $name = $request['name'];
        $phone = $request['phone'];
        $email = $request['email'];
        $address = $request['address'];
        $driver_license = $request['driver_license'];
        $password = $request['password'];
        $repeatPassword = $request['rep_password'];
        
        $user = User::where('email', $email)->exists();
        if ($user){            
            return redirect('/')->with('err','User has been registered.');
        }
        
        $user = User::create([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'driver_license' => $driver_license,
            'password' => $password            
        ]);
                
        // return back()->with('success','You have successfully upload image.');
        return redirect('/')->with('success','Register Success. Login using your email.');
    }

    public function verify(Request $request){
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:8',
        ]);

        $email = $request['email'];
        $password = $request['password'];

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            $request->session()->put('user_email', $email);
 
            // return redirect()->intended('dashboard');
            return redirect('/dashboard');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');                
    }

    public function profile(Request $request){ 
        $id = Auth::user()->id;        
        if (isset($id)){
            if ($id > 0){
                $user = User::find($id);
                $data = array(
                    'id' => $id,
                    'name' => $user['name'],
                    'email' => $user['email'],
                    'phone' => $user['phone'],
                    'address' => $user['address'],
                    'driver_license' => $user['driver_license'],
                    'created_at' => $user['created_at'],
                );                                
                return view('user.profile')->with('data', $data);
            }            
        }       
        return view('dashboard.index');
    }

    public function update(Request $request, $id){
        $this->validate($request, [
            'name' => 'required',
            'address' => 'required',
            'phone' => 'required',
            'driver_license' => 'required',            
        ]);

        $name = $request['name'];
        $address = $request['address'];
        $phone = $request['phone'];
        $driver_license = $request['driver_license'];

        $user = User::find($id);
        if ($user){
            $user->name = $name;
            $user->address = $address;
            $user->phone = $phone;
            $user->driver_license = $driver_license;
            $user->save();
            return redirect('/user/profile')->with('success','Update profile success.');
        }
        else{
            return redirect('/user/profile')->with('err','Data is not valid!');
        }                        
    }

    public function logout(Request $request){
        if($request->session()->has('user_email')){            
            $request->session()->forget('user_email');
		}        
        
        $request->session()->flush();

        Auth::logout();
 
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/')->with('success','You are logout.');
        
    }
}
