<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Rent;
use App\Models\Car;
use Exception;

class RentController extends Controller
{
    public function index(Request $request){
        if($request->session()->has('user_email')){
            $token = $request->session()->get('user_email');
		}else{
            return redirect('/');
		}

        $page = 1;
        $per_page = 30;

        $user_id = Auth::user()->id;
        if (isset($request['search'])){
            $search = $request['search'];
            $rents = Rent::whereRaw("user_id = '.$user_id.' and UPPER(trans_no) LIKE '%".strtoupper($search)."%'")->paginate(
                $perPage = 30, $columns = ['*'], $pageName = 'rents'
            );

            return view('rent.list', ['rents' => $rents, 'search' => $search]);
        }
        else{
            $rents = Rent::where('user_id', $user_id)->paginate(
                $perPage = 30, $columns = ['*'], $pageName = 'rents'
            );
        }

        return view('rent.list', ['rents' => $rents]);
    }  
    
    public function detail(Request $request, $id){         
        if (isset($id)){
            if ($id > 0){
                $rent = Rent::find($id);
                $data = array(
                    'id' => $id,
                    'trans_no' => $rent['trans_no'],
                    'start_date' => $rent['start_date'],
                    'finish_date' => $rent['finish_date'],
                    'user' => $rent['user'],
                    'car' => $rent['car']
                );
                return view('rent.detail')->with('data', $data);
            }
        }
        
        if (!isset($id) || $id == 0){                        
            // var_dump($data);
            // echo  $user_id;
            $max = Rent::whereDate('created_at', '=', date('Y-m-d'))->max('trans_no');
            if ($max){            
                // 202309250001
                $max_str = substr($max, 8); 
                $next = (int) $max_str;
                $next = $next + 1;                             
            }
            else{
                $next = 1;                
            }
            $next_no = str_pad($next, 4, '0', STR_PAD_LEFT);
            $next_no = date('Ymd') . $next_no;            

            // $cars = Car::whereRaw('1 not in (ifnull((select 1 from rents where car_id = cars.id and current_date between start_date and finish_date), 0))')->get();
            $cars = Car::get();
        }
        
        return view('rent.detail', ['next_no' => $next_no, 'cars' => $cars]);
    }

    public function create(Request $request){
        $this->validate($request, [
            'trans_no' => 'required',
            'start_date' => 'required',
            'finish_date' => 'required',
            'car' => 'required',
        ]);

        $user_id = Auth::user()->id;
        $trans_no = $request['trans_no'];
        $start_date = $request['start_date'];
        $finish_date = $request['finish_date'];
        $car_id = $request['car'];

        $start_date = date('Y-m-d', strtotime($start_date));
        $finish_date = date('Y-m-d', strtotime($finish_date));

        $car = Car::find($car_id)->first();

        $rent = Rent::whereRaw("car_id = ".$car_id." and (('".$start_date."' between start_date and finish_date) or ('".$finish_date."' between start_date and finish_date))")->first();
        if (isset($rent)){
            return redirect('/rent/detail/0')->with('err','Car with No '.$car['car_no'].' ('.$car['brand'].' - '.$car['model'].') already booked by other user!');
        }                            
        
        $rent = Rent::create([
            'trans_no' => $trans_no,
            'start_date' => $start_date,
            'finish_date' => $finish_date,
            'user_id' => $user_id,
            'car_id' => $car_id,
            'unit_price' => $car['unit_price'],
            'returned' => 0
        ]);
        
        return redirect('/rent/list')->with('success','Add new data success.');        
        
    }    
}
