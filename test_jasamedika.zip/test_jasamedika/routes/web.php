<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('layouts/app');
// });

Route::get('/', [\App\Http\Controllers\UserController::Class, 'login'])->name("user.login");
Route::get('/user/register', [\App\Http\Controllers\UserController::Class, 'register'])->name("user.register");
Route::post('/user/create', [\App\Http\Controllers\UserController::Class, 'create'])->name("user.create");
Route::post('/user/verify', [\App\Http\Controllers\UserController::Class, 'verify'])->name("user.verify");
Route::get('/user/profile', [\App\Http\Controllers\UserController::Class, 'profile'])->name("user.profile");
Route::post('/user/update/{id}', [\App\Http\Controllers\UserController::Class, 'update'])->name("user.update");
Route::get('/user/logout', [\App\Http\Controllers\UserController::Class, 'logout'])->name("user.logout");
Route::get('/dashboard', [\App\Http\Controllers\DashboardController::Class, 'index'])->name("dashboard.index");
Route::get('/car/list', [\App\Http\Controllers\CarController::Class, 'index'])->name("car.list");
Route::get('/car/detail/{id}', [\App\Http\Controllers\CarController::Class, 'detail'])->name("car.detail");
Route::post('/car/create', [\App\Http\Controllers\CarController::Class, 'create'])->name("car.create");
Route::post('/car/update/{id}', [\App\Http\Controllers\CarController::Class, 'update'])->name("car.update");
Route::get('/car/delete/{id}', [\App\Http\Controllers\CarController::Class, 'delete'])->name("car.delete");
Route::get('/rent/list', [\App\Http\Controllers\RentController::Class, 'index'])->name("rent.list");
Route::get('/rent/detail/{id}', [\App\Http\Controllers\RentController::Class, 'detail'])->name("rent.detail");
Route::post('/rent/create', [\App\Http\Controllers\RentController::Class, 'create'])->name("rent.create");
Route::get('/rent_return/list', [\App\Http\Controllers\RentReturnController::Class, 'index'])->name("rent_return.list");
Route::get('/rent_return/detail/{id}', [\App\Http\Controllers\RentReturnController::Class, 'detail'])->name("rent_return.detail");
Route::post('/rent_return/create', [\App\Http\Controllers\RentReturnController::Class, 'create'])->name("rent_return.create");
