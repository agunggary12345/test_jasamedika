<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('rent_returns', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('trans_no', 30);
            $table->date('trans_date');
            $table->smallInteger('days')->nullable();
            $table->decimal('unit_price', 16, 2)->nullable();
            $table->timestamps();
            $table->unsignedBigInteger('rent_id');
            $table->foreign('rent_id')->references('id')->on('rents')->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('rent_returns');        
    }
};
